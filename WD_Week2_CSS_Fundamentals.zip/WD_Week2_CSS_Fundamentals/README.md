# Week 2 Assignment: CSS Fundamentals

A responsive mini-project demonstrating the concepts requested in the Week 2 assignment.

## Tasks demonstrated
1. **CSS & Selectors:** external stylesheet, element/class/ID/universal selectors, colors, backgrounds, typography and text alignment.
2. **Box Model:** content, width/height, margin, padding, border, border radius, shadow and spacing.
3. **Flexbox:** flex container/items, direction, alignment, justification and gap.
4. **CSS Grid:** multi-column/row layout, gap and grid item placement.
5. **Responsive Design:** media queries for desktop, tablet and mobile.
6. **Mini Project:** combines the concepts in a responsive learning page.

## Files
- `index.html` — webpage structure and navigation interaction
- `style.css` — all styling, Flexbox, Grid and media queries

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a browser.
3. Resize the browser or use Developer Tools responsive mode to test mobile/tablet layouts.

## Before submitting
- Rename the ZIP to `WD_Week2_YourName.zip`.
- Test it on desktop and mobile.
- Upload the ZIP to Google Drive and set General access to **Anyone with the link — Viewer**.
- Submit the share link on the internship portal.

**Technologies:** HTML5, CSS3
